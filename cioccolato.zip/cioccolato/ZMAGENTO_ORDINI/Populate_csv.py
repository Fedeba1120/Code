import openpyxl
import shutil
import os
from datetime import datetime
import tkinter as tk
from tkinter import filedialog
import csv
 
def convert_to_csv(excel_file, csv_file):
    """
    Converts an Excel file to a CSV file.
    :param excel_file: Path to the Excel file to convert.
    :param csv_file: Path to the output CSV file.
    """
    # Load the Excel workbook and select the active sheet
    wb = openpyxl.load_workbook(excel_file)
    ws = wb.active
 
    # Open the CSV file for writing
    with open(csv_file, mode='w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f,delimiter=';')
 
        # Write each row from the Excel sheet to the CSV file
        for row in ws.iter_rows(values_only=True):
            writer.writerow(row)
 
    print(f"Excel file '{excel_file}' converted to CSV file '{csv_file}'.")

def populate_template():
    """
    Copies a template file, renames it, and populates it using data from an input file.
    The input file is selected by the user, and the output file is named with today's date.
    """
    # Open a file dialog to select the input file
    root = tk.Tk()
    root.withdraw()  # Hide the root window
    input_file = filedialog.askopenfilename(title="Select the input Excel file", filetypes=[("Excel files", "*.xlsx")])
 
    if not input_file:
        print("No file selected. Exiting.")
        return
 
    # Define the template file path
    template_file = r"C:\Users\ext.mquagliani\Documents\Deloitte\IPZS\ZMAGENTO_ORDINI\caricaCSV.csv"
 
    # Generate the output file name based on today's date
    today_date = datetime.now().strftime("%d%m%Y")
    output_file = f"C:\\Users\\ext.mquagliani\\Documents\\Deloitte\\IPZS\\ZMAGENTO_ORDINI\\{today_date}.xlsx"
 
    # Copy the template file and rename it
    shutil.copy(template_file, output_file)
 
    # Load the input workbook and select the active sheet
    input_wb = openpyxl.load_workbook(input_file)
    input_ws = input_wb.active
 
    # Load the copied template workbook and select the active sheet
    output_wb = openpyxl.load_workbook(output_file)
    output_ws = output_wb.active
 
    # Find the row containing "MANDT" and map column names to indices
    column_indices = {}
    for row_idx, row in enumerate(input_ws.iter_rows(values_only=True), start=1):
        if "MANDT" in row:
            column_indices = {column_name: idx for idx, column_name in enumerate(row)}
            start_row = row_idx + 1  # Data starts after the header row
            break
 
    if not column_indices:
        raise ValueError("Header 'MANDT' not found in the input file.")
 
    # Ensure required columns exist
    required_columns = ["SDDAT", "NETWR", "SHOPID", "MANDT"]
    for col in required_columns:
        if col not in column_indices:
            #raise ValueError(f"Required column '{col}' not found in the input file.")
            print("Required column '{col}' not found in the input file.")
 
    # Iterate through the rows in the input worksheet starting from the first populated row under "MANDT"
    for row in input_ws.iter_rows(min_row=start_row, values_only=True):
        if row[column_indices["MANDT"]]:  # Skip rows where "MANDT" is empty
            # Extract specific columns from the input file using dynamic indices
            data_transazione = row[column_indices["SDDAT"]] if row[column_indices["SDDAT"]] else "N/A"
            importo = int(float(row[column_indices["NETWR"]].replace(",",".").strip())) if row[column_indices["NETWR"]] else 0
            shop_id = row[column_indices["SHOPID"]] if row[column_indices["SHOPID"]] else "N/A"
 
            # Populate the template row with fixed and extracted values
            template_row = [
                "APPROVATA",  # ESITO
                "Autorizzazione",  # TIPOLOGIA OPERAZIONE
                data_transazione,  # DATA TRANSAZIONE (from SDDAT)
                "",  # DATA ULTIMA OPERAZIONE
                importo,  # IMPORTO (from NETWR)
                "MASTERCARD",  # CIRCUITO
                "",
                shop_id  # SHOP ID (from input SHOPID)
            ]
            output_ws.append(template_row)
 
    # Remove empty rows from the output worksheet
    rows_to_delete = []
    for row_idx, row in enumerate(output_ws.iter_rows(values_only=True), start=1):
        if all(cell is None or cell == "" for cell in row):
            rows_to_delete.append(row_idx)
 
    for row_idx in reversed(rows_to_delete):
        output_ws.delete_rows(row_idx)
 
    # Save the populated template to the output file
    output_wb.save(output_file)
    print(f"Template copied, renamed, and populated. Saved to {output_file}")
    convert_to_csv(output_file,f"C:\\Users\\ext.mquagliani\\Documents\\Deloitte\\IPZS\\ZMAGENTO_ORDINI\\{today_date}.csv")

# Example usage
if __name__ == "__main__":
    populate_template()
