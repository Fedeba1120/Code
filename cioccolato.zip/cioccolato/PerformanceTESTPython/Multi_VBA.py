from multiprocessing import Pool
import subprocess
import math
from tkinter import Tk, simpledialog
import pandas as pd
import time
import csv
import datetime
import os
 

 
# Load CSV data
def load_csv_data():
    csv_file = r"C:\Users\ext.mquagliani\Documents\Deloitte\PERFORMANCE_TEST\input_request2_easy.csv"
    try:
        return pd.read_csv(csv_file).set_index("OrderCodeEx")
    except FileNotFoundError:
        print(f"[ERROR] CSV file not found: {csv_file}")
        exit(1)
 
# Split list into chunks
def chunks(lst, n):
    m = min(n, len(lst))
    if m == 0:
        return
    q,r = divmod(len(lst), m)
    start = 0
    for i in range(m):
        size = q + (1 if i < r else 0)
        yield lst[start:start + size]
        start += size
 
# Save execution times to CSV
def save_execution_times(file_path, execution_times):#,Time_total):
    """Salva i tempi di esecuzione in un file CSV."""
    try:
        file_exists = os.path.exists(file_path)
        with open(file_path, "a", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
 
            # Scrivi l'intestazione solo se il file non esiste
            if not file_exists:
                writer.writerow(["WorkerID", "NUmberOfOrders","StartTime", "EndTime", "DurationMs"])
 
            # Scrivi i dati dei tempi di esecuzione
            for execution in execution_times:
                writer.writerow([execution["WorkerID"], execution["NUmberOfOrders"], execution["StartTime"], execution["EndTime"], execution["DurationMs"]])
 
        #writer.writerow("", "", "", Time_total)
        print(f"Tempi di esecuzione salvati in {file_path}")
    except Exception as e:
        print(f"Errore durante il salvataggio dei tempi di esecuzione: {e}")
 
# Run VBS script for all orders assigned to a worker
def run_vbs(args):
    worker_id, ordini, progressivi,preloaded_data = args
    count = 0
    # Prepare data for all orders assigned to the worker
    orders_data = " ".join([
        f"Order:{ordine} " + preloaded_data[ordine]
        for ordine in ordini if ordine in preloaded_data
    ])
    print(orders_data)
    start_time = datetime.datetime.now()
    subprocess.run([
        "cscript",
        "//nologo",
        "Crea_ordini_conInput copy.vbs",
        str(worker_id),
        " ".join(progressivi),
        orders_data
    ])

    end_time = datetime.datetime.now()
 
    # Calculate execution time
    duration_ms = (end_time - start_time).total_seconds() * 1000
 
    # Save execution time
    execution_times = [{
        "WorkerID": worker_id,
        "NUmberOfOrders": len(orders_data.split("Order:")) - 1,
        "StartTime": start_time.strftime("%Y-%m-%d %H:%M:%S.%f"),
        "EndTime": end_time.strftime("%Y-%m-%d %H:%M:%S.%f"),
        "DurationMs": duration_ms
    }]
    #Time_total +=duration_ms
    #print(Time_total)
    save_execution_times("execution_times.csv", execution_times)#,Time_total)
 
# Extract product codes for a given order
def extract_product_codes(order_code, data):
    if order_code in data.index:
        row = data.loc[order_code] 
        product_codes = [
            row[f"Product{i}_ProductCode"]
            for i in range(1, 5)  # Assuming up to Product4_ProductCode
            if pd.notna(row[f"Product{i}_ProductCode"])
        ]
        return product_codes
    else:
        print(f"[WARNING] No data found for CustomerCodeEx: {order_code}")
        return []
 
if __name__ == "__main__":
     
    NUM_WORKERS = 3
    start_order = simpledialog.askinteger("Input", "Inserire l'OrderCode iniziale")
    end_order = simpledialog.askinteger("Input", "Inserire l'OrderCode finale")
    ORDINI = list(range(start_order, end_order+1))
    progressive_start = int("F09600"[1:])
    progressivi_map = {ordine: f"F{(progressive_start + idx +1):05}" for idx,ordine in enumerate(ORDINI)}
    print(progressivi_map)

    # Preload data for all orders
    excel_data = load_csv_data()
 
    # Update preloaded data to include product codes
    preloaded_data = {}
    for ordine in ORDINI:
        product_codes = extract_product_codes(ordine, excel_data)
        preloaded_data[ordine] = " ".join(product_codes)
    
    
    # Prepare jobs with filtered preloaded data
    jobs = [
        (
            worker_id,
            ordini,
            [progressivi_map[ordine] for ordine in ordini if ordine in preloaded_data],
            {ordine: preloaded_data[ordine] for ordine in ordini if ordine in preloaded_data}  # Filter preloaded data for assigned orders
        )
        for worker_id, ordini in enumerate(chunks(ORDINI, NUM_WORKERS), start=1)
    ]
    # Measure performance of multiprocessing
    start_time = time.time()
    #time.sleep(20)
    with Pool(NUM_WORKERS) as p:
        p.map(run_vbs, jobs)
    end_time = time.time()
    print(start_time, end_time)
   
    # Save results to a .txt file
    results_file = "execution_times.txt"
    with open(results_file, "w", encoding="utf-8") as f:
        f.write("Execution Times:\n")
        for ordine, product_codes in preloaded_data.items():
            f.write(f"Order {ordine}: {product_codes}\n")
        f.write(f"Total execution time: {end_time - start_time:.2f} seconds\n")
 
    print(f"\nResults saved to {results_file}")
 