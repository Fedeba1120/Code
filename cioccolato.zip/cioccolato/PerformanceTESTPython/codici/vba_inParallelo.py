import subprocess
from multiprocessing import Process, Manager
import time
import csv
import pandas as pd
import os
#import pyautogui



input_file = "input_totale.csv"
sheet_name = 0

#df = pd.read_excel(input_file,sheet_name=sheet_name)
#df = pd.dropna(how='all')
#rows = df.to_dict(orient="records")

NUM_PROCESS = 3

def run_vbs_for_row(idx,results):
    #import tempfile
    #import shutil
    #import openpyxl
    start = time.time()
    
    #temp_dir = tempfile.mkdtemp()
    #temp_file = os.path.join(temp_dir,f"input_row_{idx+1}.xlsx")
    #wb = openpyxl.workbook()
    #ws = wb.active
    #ws.append(list(row.keys()))
    #ws.append(list(ros.value()))
    #wb.save(temp_file)


    log_file = f"output_row_{idx+1}.log"
    with open(log_file,"w",encoding="utf-8") as log:
        #proc=subprocess.Popen(['csript.exe','script8.vbs',temp_file],stdout=log,stderr=log)
        proc=subprocess.Popen(['wscript.exe','ScripttestNew.vbs'],stdout=log,stderr=log)
        proc.wait()
    end=time.time()
    results[idx]=end - start
    #shutil.rmtree(temp_dir)
    print( results)

if __name__=="__main__":

    manager = Manager()
    results = manager.dict()
    processes=[]
    total_start = time.time()
    for idx in range(NUM_PROCESS):

        p = Process(target=run_vbs_for_row,args=(idx,results))
        p.start()
        print("ok")
        processes.append(p)
    for p in processes:
        p.join()
    total_end = time.time()