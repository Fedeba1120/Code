# Funzione per gestire valori vuoti/null/nan
def safe_value(val):
    if pd.isna(val) or val is None or str(val).strip().lower() in ["nan", "none", ""]:
        return None
    return val

# Funzione per generare tag XML, self-closing se vuoto
def xml_tag(tag, value):
    if value is None or str(value).strip() == "" and value!=0:
        return f"<{tag}/>"
    return f"<{tag}>{value}</{tag}>"
import pandas as pd
from locust import HttpUser, task, between
#import random
import json


PRODUCT_TEMPLATE = '''    <ns1:Product>
        <ns1:ItemCode>{ItemCode}</ns1:ItemCode>
        <ns1:ProductCode>{ProductCode}</ns1:ProductCode>
        <ns1:ProductCodeEx>{ProductCodeEx}</ns1:ProductCodeEx>
        <ns1:Quantity>{Quantity}</ns1:Quantity>
        <ns1:ProductType>{ProductType}</ns1:ProductType>
        <ns1:Discount>{Discount}</ns1:Discount>
        <ns1:DiscountPercentage>{DiscountPercentage}</ns1:DiscountPercentage>
        <ns1:ShippingFees>{ShippingFees}</ns1:ShippingFees>
        <ns1:PriceEx>{PriceEx}</ns1:PriceEx>
        <ns1:Customizations>{Customizations}</ns1:Customizations>
    </ns1:Product>'''

SOAP1_TEMPLATE = '''<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns1="http://www.ipzs.it/ecommerce/b2b/types/1.0">
    <SOAP-ENV:Body>
        <ns1:OrderSimulationRequest>
            <ns1:Application>{Application}</ns1:Application>
            <ns1:CustomerType>{CustomerType}</ns1:CustomerType>
            <ns1:CustomerCode>{CustomerCode}</ns1:CustomerCode>
            <ns1:CustomerCodeEx>{CustomerCodeEx}</ns1:CustomerCodeEx>
            <ns1:FiscalCode>{FiscalCode}</ns1:FiscalCode>
            <ns1:VATNumber>{VATNumber}</ns1:VATNumber>
            <ns1:CountryISO>{CountryISO}</ns1:CountryISO>
            <ns1:Region>{Region}</ns1:Region>
            <ns1:City>{City}</ns1:City>
            <ns1:InvoiceCountryISO>{InvoiceCountryISO}</ns1:InvoiceCountryISO>
            <ns1:IPACode>{IPACode}</ns1:IPACode>
            <ns1:OrderCode>{OrderCode}</ns1:OrderCode>
            <ns1:ProductList>
{product_xml}
            </ns1:ProductList>
        </ns1:OrderSimulationRequest>
    </SOAP-ENV:Body>
</SOAP-ENV:Envelope>'''

# Carica i dati da input_request1_easy.csv forzando VATNumber e FiscalCode come stringa
input_data = pd.read_csv(
    "input_request1_easy.csv",
)
rows = input_data.to_dict(orient="records")

class SAPSoapUser(HttpUser):
    wait_time = between(1, 3)
    #host = "https://pzs.sap.ipzs.it"  #IPD
    host = "https://ipt.sap.ipzs.it"   #IPQ

    current_index = 0  # indice per la selezione sequenziale

    @task
    def order_simulation(self):
        # Seleziona la riga in modo sequenziale, poi si ferma
        if SAPSoapUser.current_index >= len(rows):
            print("Tutte le righe sono state processate. Nessuna nuova richiesta verrà inviata.")
            return
        row = rows[SAPSoapUser.current_index]
        SAPSoapUser.current_index += 1
        # Estrai i prodotti dalla riga (fino a 5, ma puoi adattare)
        products = []
        for i in range(1, 6):
            if safe_value(row.get(f"ItemCode{i}")):
                products.append({
                    "ItemCode": safe_value(row.get(f"ItemCode{i}", "")),
                    "ProductCode": safe_value(row.get(f"ProductCode{i}", "")),
                    "ProductCodeEx": safe_value(row.get(f"ProductCodeEx{i}", "")),
                    "Quantity": safe_value(row.get(f"Quantity{i}", "")),
                    "ProductType": safe_value(row.get(f"ProductType{i}", "")),
                    "Discount": safe_value(row.get(f"Discount{i}", "")),
                    "DiscountPercentage": safe_value(row.get(f"DiscountPercentage{i}", "")),
                    "ShippingFees": safe_value(row.get(f"ShippingFees{i}", "")),
                    "PriceEx": safe_value(row.get(f"PriceEx{i}", "")),
                    "Customizations": safe_value(row.get(f"Customizations{i}", ""))
                })
        # Genera la lista prodotti con tag self-closing
        product_xml = "\n".join([
            "    <ns1:Product>" +
            "".join([
                "\n        " + xml_tag(f"ns1:{k}", v) for k, v in prod.items()
            ]) +
            "\n    </ns1:Product>"
            for prod in products
        ])
        # Formatto anche i campi numerici della riga principale
        row_fmt = {k: safe_value(v) for k, v in row.items()}
        for col in ["CustomerType", "Discount", "DiscountPercentage", "ShippingFees", "PriceEx"]:
            if col in row_fmt:
                row_fmt[col] = row_fmt[col]
        # Genera i tag principali con self-closing se vuoto
        soap_body = SOAP1_TEMPLATE
        for k, v in row_fmt.items():
            soap_body = soap_body.replace(f"{{{k}}}", str(v) if v is not None else "")
        soap_body = soap_body.replace("{product_xml}", product_xml)
        headers = {"Content-Type": "text/xml; charset=utf-8", "SOAPAction": ""}
        print("SOAP inviato:\n",soap_body)
        try:
            response = self.client.post(
                "/sap/bc/srt/xip/sap/zecommerce/400/ecommerce/ecommerce",
                data=soap_body,
                headers=headers,
                auth=("EXTFBARACCHI", "Poligrafico.235"),
                name="OrderSimulationRequest",
                verify="pzs.rise.ipzs.crt"
            )
            print(f"Status code: {response.status_code}")
            if response.status_code == 200:
                print("Request SOAP eseguita con successo!\n")
            else:
                print(f"Errore nella request SOAP! Status code: {response.status_code}\n")
            print("Risposta SOAP:\n", response.text)
        except Exception as e:
            print(f"Eccezione durante la chiamata SOAP: {e}")
