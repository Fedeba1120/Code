
# ...existing code...
import pandas as pd
from locust import HttpUser, task, between
import concurrent.futures

# Carica i dati dai due file Excel
input1 = pd.read_excel("input_request1.xlsx")
input2 = pd.read_excel("input_request2.xlsx")
rows1 = input1.to_dict(orient="records")
rows2 = input2.to_dict(orient="records")

# Template SOAP per la prima request (OrderSimulationRequest)


PRODUCT_TEMPLATE = '''    <ns1:Product>
            <ns1:ItemCode>{ItemCode}</ns1:ItemCode>
            <ns1:ProductCode>{ProductCode}</ns1:ProductCode>
            <ns1:ProductCodeEx>{ProductCodeEx}</ns1:ProductCodeEx>
            <ns1:Quantity>{Quantity}</ns1:Quantity>
            <ns1:ProductType>{ProductType}</ns1:ProductType>
            <ns1:Discount>{Discount}</ns1:Discount>
            <ns1:DiscountPercentage>{DiscountPercentage}</ns1:DiscountPercentage>
            <ns1:ShippingFees>{ShippingFees}</ns1:ShippingFees>
            <ns1:PriceEx>{PriceEx}</ns1:PriceEx>
            <ns1:Customizations>{Customizations}</ns1:Customizations>
        </ns1:Product>'''

SOAP1_TEMPLATE = '''<SOAP-ENV:Envelope>
    <SOAP-ENV:Body>
        <ns1:OrderSimulationRequest>
            <ns1:Application>{Application}</ns1:Application>
            <ns1:CustomerType>{CustomerType}</ns1:CustomerType>
            <ns1:CustomerCode>{CustomerCode}</ns1:CustomerCode>
            <ns1:CustomerCodeEx>{CustomerCodeEx}</ns1:CustomerCodeEx>
            <ns1:FiscalCode>{FiscalCode}</ns1:FiscalCode>
            <ns1:VATNumber>{VATNumber}</ns1:VATNumber>
            <ns1:CountryISO>{CountryISO}</ns1:CountryISO>
            <ns1:Region>{Region}</ns1:Region>
            <ns1:City>{City}</ns1:City>
            <ns1:InvoiceCountryISO>{InvoiceCountryISO}</ns1:InvoiceCountryISO>
            <ns1:IPACode>{IPACode}</ns1:IPACode>
            <ns1:OrderCode>{OrderCode}</ns1:OrderCode>
            <ns1:ProductList>{product_xml}</ns1:ProductList>
        </ns1:OrderSimulationRequest>
    </SOAP-ENV:Body>
</SOAP-ENV:Envelope>'''

# Template SOAP per la seconda request (OrderRequest)

SOAP2_TEMPLATE = '''<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns1="http://www.ipzs.it/ecommerce/b2b/types/1.0">
    <SOAP-ENV:Body>
        <ns1:OrderRequest>
            <ns1:Application>{Application}</ns1:Application>
            <ns1:CustomerType>{CustomerType}</ns1:CustomerType>
            <ns1:CustomerCode>{CustomerCode}</ns1:CustomerCode>
            <ns1:CustomerCodeEx>{CustomerCodeEx}</ns1:CustomerCodeEx>
            <ns1:FiscalCode>{FiscalCode}</ns1:FiscalCode>
            <ns1:VATNumber>{VATNumber}</ns1:VATNumber>
            <ns1:PEC>{PEC}</ns1:PEC>
            <ns1:SDICode>{SDICode}</ns1:SDICode>
            <ns1:Order>
                <ns1:OrderCodeEx>{OrderCodeEx}</ns1:OrderCodeEx>
                <ns1:OrderCodeID>{OrderCodeID}</ns1:OrderCodeID>
                <ns1:OperationType>{OperationType}</ns1:OperationType>
                <ns1:Total>{Total}</ns1:Total>
                <ns1:ShippingFees>{ShippingFees}</ns1:ShippingFees>
                <ns1:InvoiceAddress>
                    <ns1:Address>
                        <ns1:Name1>{InvoiceName1}</ns1:Name1>
                        <ns1:Name2>{InvoiceName2}</ns1:Name2>
                        <ns1:City>{InvoiceCity}</ns1:City>
                        <ns1:PostalCode>{InvoicePostalCode}</ns1:PostalCode>
                        <ns1:Street>{InvoiceStreet}</ns1:Street>
                        <ns1:HouseNumber>{InvoiceHouseNumber}</ns1:HouseNumber>
                        <ns1:Region>{InvoiceRegion}</ns1:Region>
                        <ns1:CountryISO>{InvoiceCountryISO}</ns1:CountryISO>
                        <ns1:LanguageISO>{InvoiceLanguageISO}</ns1:LanguageISO>
                        <ns1:TelephoneList>
                            <ns1:Telephone>
                                <ns1:NumTelephone>{InvoiceTelephone}</ns1:NumTelephone>
                            </ns1:Telephone>
                        </ns1:TelephoneList>
                        <ns1:FAXList>
                            <ns1:FAX>
                                <ns1:NumFAX>{InvoiceFAX}</ns1:NumFAX>
                            </ns1:FAX>
                        </ns1:FAXList>
                        <ns1:EmailList>
                            <ns1:Email>
                                <ns1:AddresseMail>{InvoiceEmail}</ns1:AddresseMail>
                            </ns1:Email>
                        </ns1:EmailList>
                    </ns1:Address>
                </ns1:InvoiceAddress>
                <ns1:ShippingAddress>
                    <ns1:Address>
                        <ns1:Name1>{ShippingName1}</ns1:Name1>
                        <ns1:Name2>{ShippingName2}</ns1:Name2>
                        <ns1:City>{ShippingCity}</ns1:City>
                        <ns1:PostalCode>{ShippingPostalCode}</ns1:PostalCode>
                        <ns1:Street>{ShippingStreet}</ns1:Street>
                        <ns1:HouseNumber>{ShippingHouseNumber}</ns1:HouseNumber>
                        <ns1:Region>{ShippingRegion}</ns1:Region>
                        <ns1:CountryISO>{ShippingCountryISO}</ns1:CountryISO>
                        <ns1:LanguageISO>{ShippingLanguageISO}</ns1:LanguageISO>
                        <ns1:TelephoneList>
                            <ns1:Telephone>
                                <ns1:NumTelephone>{ShippingTelephone}</ns1:NumTelephone>
                            </ns1:Telephone>
                        </ns1:TelephoneList>
                        <ns1:FAXList>
                            <ns1:FAX>
                                <ns1:NumFAX>{ShippingFAX}</ns1:NumFAX>
                            </ns1:FAX>
                        </ns1:FAXList>
                        <ns1:EmailList>
                            <ns1:Email>
                                <ns1:AddresseMail>{ShippingEmail}</ns1:AddresseMail>
                            </ns1:Email>
                        </ns1:EmailList>
                    </ns1:Address>
                </ns1:ShippingAddress>
                <ns1:Retreat>{Retreat}</ns1:Retreat>
                <ns1:PaymentType>{PaymentType}</ns1:PaymentType>
                <ns1:PaymentDate>{PaymentDate}</ns1:PaymentDate>
                <ns1:Ksig>{Ksig}</ns1:Ksig>
                <ns1:TerminalID>{TerminalID}</ns1:TerminalID>
                <ns1:ShopID>{ShopID}</ns1:ShopID>
                <ns1:RefTranID>{RefTranID}</ns1:RefTranID>
                <ns1:PaymentID>{PaymentID}</ns1:PaymentID>
                <ns1:ProductList>{product_xml}</ns1:ProductList>
            </ns1:Order>
        </ns1:OrderRequest>
    </SOAP-ENV:Body>
</SOAP-ENV:Envelope>'''

class SAPSoapUser(HttpUser):
    wait_time = between(1, 3)
    host = "https://pzs.sap.ipzs.it"

    @task
    def parallel_requests(self):
        import random, json
        # Scegli una riga random per ciascuna request
        row1 = random.choice(rows1)
        row2 = random.choice(rows2)

        # Gestione ProductList per la prima request (colonna ProductList in formato JSON)
        product_list = json.loads(row1["ProductList"]) if "ProductList" in row1 and row1["ProductList"] else []
        product_xml = "\n".join([PRODUCT_TEMPLATE.format(**prod) for prod in product_list])

        # Prepara le due request SOAP
        soap1 = SOAP1_TEMPLATE.format(product_xml=product_xml, **row1)
        soap2 = SOAP2_TEMPLATE.format(**row2)

        headers = {"Content-Type": "text/xml; charset=utf-8", "SOAPAction": ""}

        def call1():
            self.client.post(
                "/sap/bc/srt/xip/sap/zecommerce/400/ecommerce/ecommerce",
                data=soap1,
                headers=headers,
                name="OrderSimulationRequest"
            )

        def call2():
            self.client.post(
                "/sap/bc/srt/xip/sap/zecommerce/400/ecommerce/ecommerce",
                data=soap2,
                headers=headers,
                name="OrderRequest"
            )

        # Esegui le due chiamate in parallelo
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = [executor.submit(call1), executor.submit(call2)]
            concurrent.futures.wait(futures)
