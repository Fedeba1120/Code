
import pandas as pd
from locust import HttpUser, task, between

def safe_value(val):
    if pd.isna(val) or val is None or str(val).strip().lower() in ["nan", "none", ""]:
        return ""
    return str(val)

def xml_tag(tag, value):
    #if value is None or str(value).strip():
    if value is None or str(value).strip() == "" and value!=0:
        return f"<{tag}/>"
    return f"<{tag}>{value}</{tag}>"

def build_address_xml(prefix, row):
    # Crea blocco <ns1:Address> per Invoice/Shipping
    # Mapping per i campi reali del CSV
        tel = safe_value(row.get(f'{prefix}Telephone'))
        fax = safe_value(row.get(f'{prefix}FAX'))
        email = safe_value(row.get(f'{prefix}Email'))
        return (f"<ns1:Address>\n"
            f"  {xml_tag('ns1:Name1', safe_value(row.get(f'{prefix}Name1')))}\n"
            f"  {xml_tag('ns1:Name2', safe_value(row.get(f'{prefix}Name2')))}\n"
            f"  {xml_tag('ns1:City', safe_value(row.get(f'{prefix}City')))}\n"
            f"  {xml_tag('ns1:PostalCode', safe_value(row.get(f'{prefix}PostalCode')))}\n"
            f"  {xml_tag('ns1:Street', safe_value(row.get(f'{prefix}Street')))}\n"
            f"  {xml_tag('ns1:HouseNumber', safe_value(row.get(f'{prefix}HouseNumber')))}\n"
            f"  {xml_tag('ns1:Region', safe_value(row.get(f'{prefix}Region')))}\n"
            f"  {xml_tag('ns1:CountryISO', safe_value(row.get(f'{prefix}CountryISO')))}\n"
            f"  {xml_tag('ns1:LanguageISO', safe_value(row.get(f'{prefix}LanguageISO')))}\n"
            f"  <ns1:TelephoneList>\n"
            f"    <ns1:Telephone>\n"
            f"      <ns1:NumTelephone>{tel if tel else ''}</ns1:NumTelephone>\n"
            f"    </ns1:Telephone>\n"
            f"  </ns1:TelephoneList>\n"
            f"  <ns1:FAXList>\n"
            f"    <ns1:FAX>\n"
            f"      <ns1:NumFAX>{fax if fax else ''}</ns1:NumFAX>\n"
            f"    </ns1:FAX>\n"
            f"  </ns1:FAXList>\n"
            f"  <ns1:EmailList>\n"
            f"    <ns1:Email>\n"
            f"      <ns1:AddresseMail>{email if email else ''}</ns1:AddresseMail>\n"
            f"    </ns1:Email>\n"
            f"  </ns1:EmailList>\n"
            f"</ns1:Address>")

def build_product_xml(row):
    products = []
    for i in range(1, 6):
        prefix = f'Product{i}_'
        if safe_value(row.get(f'{prefix}ItemCode')):
            products.append(
                f"<ns1:Product>\n"
                f"  {xml_tag('ns1:ItemCode', safe_value(row.get(f'{prefix}ItemCode')))}\n"
                f"  {xml_tag('ns1:ProductCode', safe_value(row.get(f'{prefix}ProductCode')))}\n"
                f"  {xml_tag('ns1:ProductCodeEx', safe_value(row.get(f'{prefix}ProductCodeEx')))}\n"
                f"  {xml_tag('ns1:Quantity', safe_value(row.get(f'{prefix}Quantity')))}\n"
                f"  {xml_tag('ns1:ProductType', safe_value(row.get(f'{prefix}ProductType')))}\n"
                f"  {xml_tag('ns1:Discount', safe_value(row.get(f'{prefix}Discount')))}\n"
                f"  {xml_tag('ns1:DiscountPercentage', safe_value(row.get(f'{prefix}DiscountPercentage')))}\n"
                f"  {xml_tag('ns1:PriceEx', safe_value(row.get(f'{prefix}PriceEx')))}\n"
                f"  {xml_tag('ns1:AvailabilityDate', safe_value(row.get(f'{prefix}AvailabilityDate')))}\n"
                f"</ns1:Product>"
            )
    return "\n".join(products)

def build_order_xml(row):
    return (f"<ns1:Order>\n"
            f"  {xml_tag('ns1:OrderCodeEx', safe_value(row.get('OrderCodeEx')))}\n"
            f"  {xml_tag('ns1:OrderCodeID', safe_value(row.get('OrderCodeID')))}\n"
            f"  {xml_tag('ns1:OperationType', safe_value(row.get('OperationType')))}\n"
            f"  {xml_tag('ns1:Total', safe_value(row.get('Total')))}\n"
            f"  {xml_tag('ns1:ShippingFees', safe_value(row.get('ShippingFees')))}\n"
            f"  <ns1:InvoiceAddress>\n"
            f"{build_address_xml('Invoice', row)}\n"
            f"  </ns1:InvoiceAddress>\n"
            f"  <ns1:ShippingAddress>\n"
            f"{build_address_xml('Shipping', row)}\n"
            f"  </ns1:ShippingAddress>\n"
            f"  {xml_tag('ns1:Retreat', safe_value(row.get('Retreat')))}\n"
            f"  {xml_tag('ns1:PaymentType', safe_value(row.get('PaymentType')))}\n"
            f"  {xml_tag('ns1:PaymentDate', safe_value(row.get('PaymentDate')))}\n"
            f"  {xml_tag('ns1:Ksig', safe_value(row.get('Ksig')))}\n"
            f"  {xml_tag('ns1:TerminalID', safe_value(row.get('TerminalID')))}\n"
            f"  {xml_tag('ns1:ShopID', safe_value(row.get('ShopID')))}\n"
            f"  {xml_tag('ns1:RefTranID', safe_value(row.get('RefTranID')))}\n"
            f"  {xml_tag('ns1:PaymentID', safe_value(row.get('PaymentID')))}\n"
            f"  <ns1:ProductList>\n"
            f"{build_product_xml(row)}\n"
            f"  </ns1:ProductList>\n"
            f"</ns1:Order>")

SOAP2_TEMPLATE = '''<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns1="http://www.ipzs.it/ecommerce/b2b/types/1.0">
    <SOAP-ENV:Body>
        <ns1:OrderRequest>
            {main_tags}
            {order_xml}
        </ns1:OrderRequest>
    </SOAP-ENV:Body>
</SOAP-ENV:Envelope>'''

#input_data = pd.read_csv("input_request2_easy.csv", dtype=str)
input_data = pd.read_csv(r"C:\Users\ext.mquagliani\Documents\Deloitte\PERFORMANCE_TEST\input_request2_easy.csv", dtype=str)
rows = input_data.to_dict(orient="records")

class SAPSoapUser(HttpUser):
    wait_time = between(1, 3)
    #host = "https://pzs.sap.ipzs.it"  #IPD
    host = "https://ipt.sap.ipzs.it"   #IPQ
    current_index = 0

    @task
    def order_request(self):
        #if SAPSoapUser.current_index >= len(rows):
        #    print("Tutte le righe sono state processate. Nessuna nuova richiesta verrà inviata.")
        #    return
        #row = rows[SAPSoapUser.current_index]
        row = rows[0]
        #SAPSoapUser.current_index += 1
        # Tag principali fuori da <Order>
        main_tags = "\n".join([
            xml_tag('ns1:Application', safe_value(row.get('Application'))),
            xml_tag('ns1:CustomerType', safe_value(row.get('CustomerType'))),
            xml_tag('ns1:CustomerCode', safe_value(row.get('CustomerCode'))),
            xml_tag('ns1:CustomerCodeEx', safe_value(row.get('CustomerCodeEx'))),
            xml_tag('ns1:FiscalCode', safe_value(row.get('FiscalCode'))),
            xml_tag('ns1:VATNumber', safe_value(row.get('VATNumber'))),
            xml_tag('ns1:PEC', safe_value(row.get('PEC'))),
            xml_tag('ns1:SDICode', safe_value(row.get('SDICode')))
        ])
        order_xml = build_order_xml(row)
        soap_body = SOAP2_TEMPLATE.format(main_tags=main_tags, order_xml=order_xml)
        headers = {"Content-Type": "text/xml; charset=utf-8", "SOAPAction": ""}
        print("SOAP inviato:\n", soap_body)
        try:
            response = self.client.post(
                "/sap/bc/srt/xip/sap/zecommerce/400/ecommerce/ecommerce",
                data=soap_body,
                headers=headers,
                #auth=("EXTFBARACCHI", "Poligrafico.235"),
                auth=("WEB_MAGENTO", "Poligrafico_2025$"),
                name="OrderRequest",
                verify="pzs.rise.ipzs.crt"
            )
            print(f"Status code: {response.status_code}")
            if response.status_code == 200:
                print("Request SOAP eseguita con successo!\n")
            else:
                print(f"Errore nella request SOAP! Status code: {response.status_code}\n")
            print("Risposta SOAP:\n", response.text)
        except Exception as e:
            print(f"Eccezione durante la chiamata SOAP: {e}")
