import pandas as pd
from locust import HttpUser, task, between, LoadTestShape
#import concurrent.futures
from datetime import datetime, timedelta
import json
import time
import threading
import csv
from locust import events
from openpyxl import workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from threading import Lock
import pdb 

def show_popup_with_metrics(title: str, num_inputs: int, avg_time: float, total_time: float, auto_close_ms: int = 4000):
    #try:
        def popup():
            try:
                import tkinter as tk
                from tkinter import ttk

                
                root = tk.Tk()
                root.title(title)
                #root.attributes('-topmost',True)
                root.geometry('420x220+50+50')

                #frm=ttk.Frame(root,padding=12)
                #frm.pack(fill='both',expand=True)
                #print(num_inputs)
                #print(avg_time)
                #print(total_time)

                metrics_message = (
                    f"Numero di ordini di vendita creati: {num_inputs}\n"
                    f"Tempo medio per ognuno: {avg_time:.2f} ms\n"
                    f"Tempo totale impiegato: {total_time:.2f} ms\n"
                )
                print(metrics_message)
                label=tk.Label(root,text=metrics_message)
                label.pack(pady=20)
                
                #bottone chiudi
                #btn=ttk.Button(text='Chiudi',command=root.destroy)
                #btn.pack(anchor='e',pady=(10,0))
                
                #auto-close
                #root.after(auto_close_ms,root.destroy)
                root.mainloop()
            except:
                pass

        threading.Thread(target=popup,daemon=True).start()

    #except Exception:
     #   print(Exception.)
      #  pass

def pretty_time(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

def print_banner(title: str):
    line = "=" * 60
    print(f"\n{line}\n{title}\n{line}")

def print_timing(name: str,start:datetime,end:datetime):
    duration_ms = (end - start).total_seconds()*1000
    print_banner(f"{name}")
    print(f"Start time: {pretty_time(start)}")
    print(f"End time: {pretty_time(end)}")
    print(f"Duration: {duration_ms:.1f} ms")

    msg=(
        f"Start time: {pretty_time(start)}\n"
        f"End time: {pretty_time(end)}\n"
        f"Duration: {duration_ms:.1f} ms\n"
    )

# Funzione per salvare i dati della risposta in un file Excel

def save_response_to_excel(response_data, file_path):
    try:
        try:
            existing_data = pd.read_excel(file_path)
        except FileNotFoundError:
            existing_data = pd.DataFrame()

        new_data = pd.DataFrame(response_data)
        combinated_data = pd.concat([existing_data,new_data],ignore_index=True)
        combinated_data.to_excel(file_path,index=False)

        wb = load_workbook(file_path)
        ws = wb.active

        fill_red = PatternFill(start_color="FF0000", end_color="FF0000",fill_type="solid")
        print("caiooooooo")
        print(ws.max_row)
        print(ws.max_column)
        for row in ws.iter_rows(min_row = 2, max_row = ws.max_row, min_col = 1,max_col = ws.max_column):
            for cell in row:
                if cell.column_letter =="B":
                    if "Ordine creato" not in str(cell.value) :
                        for c in row:
                            c.fill = fill_red
                    if cell.column_letter =="A":
                        if cell.value != 200:
                            for c in row:
                                c.fill = fill_red
        
        wb.save(file_path)

        print(f"Dati salvati in {file_path}")
    except Exception as e:
        print(f"Errore durante il salvataggio in Excel: {e}")
    
def safe_value(val):
    if pd.isna(val) or val is None or str(val).strip().lower() in ["nan", "none", ""]:
        return ""
    return str(val)

def xml_tag(tag, value):
    #if value is None or str(value).strip():
    if value is None or str(value).strip() == "" and value!=0:
        return f"<{tag}/>"
    return f"<{tag}>{value}</{tag}>"

_now = datetime.now()
START_AT = _now.replace(microsecond=0) + timedelta(seconds=1)
#print(START_AT)

def wait_until_start():
    while datetime.now() < START_AT:
        #sleep in piccoli intervalli 
        time.sleep(0.005)

input_data1 = pd.read_csv(r"C:\Users\ext.mquagliani\Documents\Deloitte\PERFORMANCE_TEST\input_request1_easy.csv", dtype=str)
rows1 = input_data1.to_dict(orient="records")


PRODUCT_TEMPLATE = '''    <ns1:Product>
        <ns1:ItemCode>{ItemCode}</ns1:ItemCode>
        <ns1:ProductCode>{ProductCode}</ns1:ProductCode>
        <ns1:ProductCodeEx>{ProductCodeEx}</ns1:ProductCodeEx>
        <ns1:Quantity>{Quantity}</ns1:Quantity>
        <ns1:ProductType>{ProductType}</ns1:ProductType>
        <ns1:Discount>{Discount}</ns1:Discount>
        <ns1:DiscountPercentage>{DiscountPercentage}</ns1:DiscountPercentage>
        <ns1:ShippingFees>{ShippingFees}</ns1:ShippingFees>
        <ns1:PriceEx>{PriceEx}</ns1:PriceEx>
        <ns1:Customizations>{Customizations}</ns1:Customizations>
    </ns1:Product>'''

SOAP1_TEMPLATE = '''<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns1="http://www.ipzs.it/ecommerce/b2b/types/1.0">
    <SOAP-ENV:Body>
        <ns1:OrderSimulationRequest>
            <ns1:Application>{Application}</ns1:Application>
            <ns1:CustomerType>{CustomerType}</ns1:CustomerType>
            <ns1:CustomerCode>{CustomerCode}</ns1:CustomerCode>
            <ns1:CustomerCodeEx>{CustomerCodeEx}</ns1:CustomerCodeEx>
            <ns1:FiscalCode>{FiscalCode}</ns1:FiscalCode>
            <ns1:VATNumber>{VATNumber}</ns1:VATNumber>
            <ns1:CountryISO>{CountryISO}</ns1:CountryISO>
            <ns1:Region>{Region}</ns1:Region>
            <ns1:City>{City}</ns1:City>
            <ns1:InvoiceCountryISO>{InvoiceCountryISO}</ns1:InvoiceCountryISO>
            <ns1:IPACode>{IPACode}</ns1:IPACode>
            <ns1:OrderCode>{OrderCode}</ns1:OrderCode>
            <ns1:ProductList>
{product_xml}
            </ns1:ProductList>
        </ns1:OrderSimulationRequest>
    </SOAP-ENV:Body>
</SOAP-ENV:Envelope>'''

class Request1User(HttpUser):
    weight = 100
    wait_time = between(1, 3)
    #host = "https://pzs.sap.ipzs.it" #IPD
    host = "https://ipt.sap.ipzs.it"  #IPQ
    data_index = 1
    total_requests = 0
    total_time_ms = 0
    lock = Lock()
    user_id = 1
    @task
    def order_simulation(self):
        #wait_until_start
        start_ts = datetime.now()
        # Seleziona la riga in modo sequenziale, poi si ferma
        #if Request1User.current_index >= len(rows1):
        #    print("Tutte le righe sono state processate. Nessuna nuova richiesta verrà inviata.")
        #    return
        #row = rows1[0]
        #pdb.set_trace()
        with Request1User.lock:
            if Request1User.data_index >=len(rows1):
                return
            row = rows1[Request1User.data_index]
            print(f"Utente Request1 numero {Request1User.user_id} sta processando l'ordine {Request1User.data_index}")
            Request1User.user_id +=1
            Request1User.data_index +=1
        # if self.data_index >=len(rows1):
        #     return #termina esecuzione, righe finite
        # row = rows1[self.data_index]
        #self.data_index +=1 

        #Request1User.current_index += 1
        # Estrai i prodotti dalla riga (fino a 5, ma puoi adattare)
        products = []
        for i in range(1, 6):
            if safe_value(row.get(f"ItemCode{i}")):
                products.append({
                    "ItemCode": safe_value(row.get(f"ItemCode{i}", "")),
                    "ProductCode": safe_value(row.get(f"ProductCode{i}", "")),
                    "ProductCodeEx": safe_value(row.get(f"ProductCodeEx{i}", "")),
                    "Quantity": safe_value(row.get(f"Quantity{i}", "")),
                    "ProductType": safe_value(row.get(f"ProductType{i}", "")),
                    "Discount": safe_value(row.get(f"Discount{i}", "")),
                    "DiscountPercentage": safe_value(row.get(f"DiscountPercentage{i}", "")),
                    "ShippingFees": safe_value(row.get(f"ShippingFees{i}", "")),
                    "PriceEx": safe_value(row.get(f"PriceEx{i}", "")),
                    "Customizations": safe_value(row.get(f"Customizations{i}", ""))
                })
        # Genera la lista prodotti con tag self-closing
        product_xml = "\n".join([
            "    <ns1:Product>" +
            "".join([
                "\n        " + xml_tag(f"ns1:{k}", v) for k, v in prod.items()
            ]) +
            "\n    </ns1:Product>"
            for prod in products
        ])
        # Formatto anche i campi numerici della riga principale
        row_fmt = {k: safe_value(v) for k, v in row.items()}
        for col in ["CustomerType", "Discount", "DiscountPercentage", "ShippingFees", "PriceEx"]:
            if col in row_fmt:
                row_fmt[col] = row_fmt[col]
        # Genera i tag principali con self-closing se vuoto
        soap_body = SOAP1_TEMPLATE
        for k, v in row_fmt.items():
            soap_body = soap_body.replace(f"{{{k}}}", str(v) if v is not None else "")
        soap_body = soap_body.replace("{product_xml}", product_xml)
        headers = {"Content-Type": "text/xml; charset=utf-8", "SOAPAction": ""}
        print("SOAP inviato:\n",soap_body)
        try:
            response = self.client.post(
                "/sap/bc/srt/xip/sap/zecommerce/400/ecommerce/ecommerce",
                data=soap_body,
                headers=headers,
                auth=("WEB_MAGENTO", "Poligrafico_2025$"),
                name="OrderSimulationRequest",
                verify="pzs.rise.ipzs.crt"
            )
            end_ts = datetime.now()
            print(f"Status code: {response.status_code}")
            if response.status_code == 200:
                print("Request SOAP 1 eeguita con successo!\n")
                #print(f"OrderSimulationRequest",start_ts,end_ts)
            else:
                print(f"Errore nella request SOAP1 Status code: {response.status_code}\n")
            #print("Risposta SOAP 1:\n", response.text)

            end_ts = datetime.now()
            duration_ms = (end_ts - start_ts).total_seconds() * 1000
            self.total_requests += 1
            self.total_time_ms += duration_ms

            avg_time_ms = self.total_time_ms / self.total_requests
            print("time",end_ts)


            # Mostra il popup con le metriche
            if self.total_requests == len(rows1):
                show_popup_with_metrics(
                "OrderSimulationRequest Metrics",
                self.total_requests,
                avg_time_ms,
                self.total_time_ms
             )

            save_metrics_to_file(r"C:\Users\ext.mquagliani\Documents\Deloitte\IPZS\PerformanceTESTPython\MetricsSimulationOrder.csv",self.total_requests,avg_time_ms,self.total_time_ms)

            # Salva la risposta in un file Excel
            print("save")
            response_data = [{"status_code": response.status_code, "content": response.text}]
            save_response_to_excel(response_data, r"OrderSimulationRequest_data.xlsx")
        
        except Exception as e:
            print(f"Eccezione durante la chiamata SOAP: {e}")


    
input_data2 = pd.read_csv(r"C:\Users\ext.mquagliani\Documents\Deloitte\PERFORMANCE_TEST\input_request2_easy.csv", dtype=str)
rows2= input_data2.to_dict(orient="records")

def build_address_xml(prefix, row):
    # Crea blocco <ns1:Address> per Invoice/Shipping
    # Mapping per i campi reali del CSV
        tel = safe_value(row.get(f'{prefix}Telephone'))
        fax = safe_value(row.get(f'{prefix}FAX'))
        email = safe_value(row.get(f'{prefix}Email'))
        return (f"<ns1:Address>\n"
            f"  {xml_tag('ns1:Name1', safe_value(row.get(f'{prefix}Name1')))}\n"
            f"  {xml_tag('ns1:Name2', safe_value(row.get(f'{prefix}Name2')))}\n"
            f"  {xml_tag('ns1:City', safe_value(row.get(f'{prefix}City')))}\n"
            f"  {xml_tag('ns1:PostalCode', safe_value(row.get(f'{prefix}PostalCode')))}\n"
            f"  {xml_tag('ns1:Street', safe_value(row.get(f'{prefix}Street')))}\n"
            f"  {xml_tag('ns1:HouseNumber', safe_value(row.get(f'{prefix}HouseNumber')))}\n"
            f"  {xml_tag('ns1:Region', safe_value(row.get(f'{prefix}Region')))}\n"
            f"  {xml_tag('ns1:CountryISO', safe_value(row.get(f'{prefix}CountryISO')))}\n"
            f"  {xml_tag('ns1:LanguageISO', safe_value(row.get(f'{prefix}LanguageISO')))}\n"
            f"  <ns1:TelephoneList>\n"
            f"    <ns1:Telephone>\n"
            f"      <ns1:NumTelephone>{tel if tel else ''}</ns1:NumTelephone>\n"
            f"    </ns1:Telephone>\n"
            f"  </ns1:TelephoneList>\n"
            f"  <ns1:FAXList>\n"
            f"    <ns1:FAX>\n"
            f"      <ns1:NumFAX>{fax if fax else ''}</ns1:NumFAX>\n"
            f"    </ns1:FAX>\n"
            f"  </ns1:FAXList>\n"
            f"  <ns1:EmailList>\n"
            f"    <ns1:Email>\n"
            f"      <ns1:AddresseMail>{email if email else ''}</ns1:AddresseMail>\n"
            f"    </ns1:Email>\n"
            f"  </ns1:EmailList>\n"
            f"</ns1:Address>")

def build_product_xml(row):
    products = []
    for i in range(1, 6):
        prefix = f'Product{i}_'
        if safe_value(row.get(f'{prefix}ItemCode')):
            products.append(
                f"<ns1:Product>\n"
                f"  {xml_tag('ns1:ItemCode', safe_value(row.get(f'{prefix}ItemCode')))}\n"
                f"  {xml_tag('ns1:ProductCode', safe_value(row.get(f'{prefix}ProductCode')))}\n"
                f"  {xml_tag('ns1:ProductCodeEx', safe_value(row.get(f'{prefix}ProductCodeEx')))}\n"
                f"  {xml_tag('ns1:Quantity', safe_value(row.get(f'{prefix}Quantity')))}\n"
                f"  {xml_tag('ns1:ProductType', safe_value(row.get(f'{prefix}ProductType')))}\n"
                f"  {xml_tag('ns1:Discount', safe_value(row.get(f'{prefix}Discount')))}\n"
                f"  {xml_tag('ns1:DiscountPercentage', safe_value(row.get(f'{prefix}DiscountPercentage')))}\n"
                f"  {xml_tag('ns1:PriceEx', safe_value(row.get(f'{prefix}PriceEx')))}\n"
                f"  {xml_tag('ns1:AvailabilityDate', safe_value(row.get(f'{prefix}AvailabilityDate')))}\n"
                f"</ns1:Product>"
            )
    return "\n".join(products)

def build_order_xml(row):
    return (f"<ns1:Order>\n"
            f"  {xml_tag('ns1:OrderCodeEx', safe_value(row.get('OrderCodeEx')))}\n"
            f"  {xml_tag('ns1:OrderCodeID', safe_value(row.get('OrderCodeID')))}\n"
            f"  {xml_tag('ns1:OperationType', safe_value(row.get('OperationType')))}\n"
            f"  {xml_tag('ns1:Total', safe_value(row.get('Total')))}\n"
            f"  {xml_tag('ns1:ShippingFees', safe_value(row.get('ShippingFees')))}\n"
            f"  <ns1:InvoiceAddress>\n"
            f"{build_address_xml('Invoice', row)}\n"
            f"  </ns1:InvoiceAddress>\n"
            f"  <ns1:ShippingAddress>\n"
            f"{build_address_xml('Shipping', row)}\n"
            f"  </ns1:ShippingAddress>\n"
            f"  {xml_tag('ns1:Retreat', safe_value(row.get('Retreat')))}\n"
            f"  {xml_tag('ns1:PaymentType', safe_value(row.get('PaymentType')))}\n"
            f"  {xml_tag('ns1:PaymentDate', safe_value(row.get('PaymentDate')))}\n"
            f"  {xml_tag('ns1:Ksig', safe_value(row.get('Ksig')))}\n"
            f"  {xml_tag('ns1:TerminalID', safe_value(row.get('TerminalID')))}\n"
            f"  {xml_tag('ns1:ShopID', safe_value(row.get('ShopID')))}\n"
            f"  {xml_tag('ns1:RefTranID', safe_value(row.get('RefTranID')))}\n"
            f"  {xml_tag('ns1:PaymentID', safe_value(row.get('PaymentID')))}\n"
            f"  <ns1:ProductList>\n"
            f"{build_product_xml(row)}\n"
            f"  </ns1:ProductList>\n"
            f"</ns1:Order>")

SOAP2_TEMPLATE = '''<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns1="http://www.ipzs.it/ecommerce/b2b/types/1.0">
    <SOAP-ENV:Body>
        <ns1:OrderRequest>
            {main_tags}
            {order_xml}
        </ns1:OrderRequest>
    </SOAP-ENV:Body>
</SOAP-ENV:Envelope>'''

class Request2User(HttpUser):
    weight = 1
    user_id = 1
    wait_time = between(1, 3)
    #host = "https://pzs.sap.ipzs.it"  #IPD
    host = "https://ipt.sap.ipzs.it"   #IPQ
    data_index = 1
    total_requests = 0
    total_time_ms = 0
    lock = Lock()
    @task
    def order_request(self):
        #wait_until_start()
        start_ts = datetime.now()
        #if Request2User.current_index >= len(rows2):
        #    print(f"Riga {Request2User.current_index} processata, passo alla prossima.")
        #    return
        #row = rows2[0]

        #pdb.set_trace()
        with Request2User.lock:
            if Request2User.data_index >=len(rows2):
                return
            row = rows2[Request2User.data_index]
            print(f"Utente Request2 numero {Request2User.user_id} sta processando l'ordine {Request2User.data_index}")
            Request2User.user_id +=1
            Request2User.data_index +=1
        # if self.data_index >=len(rows2):
        #     return #termina esecuzione, righe finite
        # row = rows2[self.data_index]
        # self.data_index +=1 
        #row = rows2[0]
        #Request2User.current_index += 1
        # Tag principali fuori da <Order>
        main_tags = "\n".join([
            xml_tag('ns1:Application', safe_value(row.get('Application'))),
            xml_tag('ns1:CustomerType', safe_value(row.get('CustomerType'))),
            xml_tag('ns1:CustomerCode', safe_value(row.get('CustomerCode'))),
            xml_tag('ns1:CustomerCodeEx', safe_value(row.get('CustomerCodeEx'))),
            xml_tag('ns1:FiscalCode', safe_value(row.get('FiscalCode'))),
            xml_tag('ns1:VATNumber', safe_value(row.get('VATNumber'))),
            xml_tag('ns1:PEC', safe_value(row.get('PEC'))),
            xml_tag('ns1:SDICode', safe_value(row.get('SDICode')))
        ])
        order_xml = build_order_xml(row)
        soap_body = SOAP2_TEMPLATE.format(main_tags=main_tags, order_xml=order_xml)
        headers = {"Content-Type": "text/xml; charset=utf-8", "SOAPAction": ""}
        print("SOAP inviato:\n", soap_body)
        try:
            response = self.client.post(
                "/sap/bc/srt/xip/sap/zecommerce/400/ecommerce/ecommerce",
                data=soap_body,
                headers=headers,
                auth=("WEB_MAGENTO", "Poligrafico_2025$"),
                name="OrderRequest",
                verify="pzs.rise.ipzs.crt"
            )
            end_ts = datetime.now()
            duration_ms = (end_ts - start_ts).total_seconds() * 1000
            self.total_requests += 1
            self.total_time_ms += duration_ms

            avg_time_ms = self.total_time_ms / self.total_requests

            #Mostra il popup con le metriche
            if self.total_requests == len(rows2):
                show_popup_with_metrics(
                    "OrderRequest Metrics",
                    self.total_requests,
                    avg_time_ms,
                    self.total_time_ms
                )

            save_metrics_to_file(r"C:\Users\ext.mquagliani\Documents\Deloitte\IPZS\PerformanceTESTPython\MetricsCreazioneOrdini.csv",self.total_requests,avg_time_ms,self.total_time_ms)
            # Salva la risposta in un file Excel
            response_data = [{"status_code": response.status_code, "content": response.text}]
            save_response_to_excel(response_data, "OrderRequestresponse_data.xlsx")
                
                
            
            print(f"Status code: {response.status_code}")
            if response.status_code == 200:
                print("Request SOAP 2 eseguita con successo!\n")
                #print(f"OrderRequest",start_ts,end_ts)
            else:
                print(f"Errore nella request SOAP2 Status code: {response.status_code}\n")
            #print("Risposta SOAP 2:\n", response.text)
        except Exception as e:
            print(f"Eccezione durante la chiamata SOAP: {e}")


def save_metrics_to_file(file_path,num_inputs,avg_time,total_time):
    try:
        with open (file_path,"w",encoding="utf-8") as f:
            f.write("MetricheFinali\n")
            f.write("=================\n")
            f.write(f"Numero di input: {num_inputs}\n")
            f.write(f"Tempo medio: {avg_time:.2f} ms\n")
            f.write(f"Tempo totale: {total_time:.2f} ms\n")
        print(f"Metriche salvate in {file_path}")
    except:
        pass
# @events.quitting.add_listener
# def on_locust_quit(environment,**kwargs):
#     total_responses = environment.stats.total.num_requests
#     avg_response_time = environment.stats.total.avg_response_time
#     total_response_time = environment.stats.total.total_response_time

# class CustomLoadTestShape(LoadTestShape):

#     """

#     Custom shape to control the number of users for Request1User and Request2User.

#     """

#     def tick(self):

#         run_time = self.get_run_time()
 
#         if run_time < 2*3600:  # Run for 1 hour

#             return (2,2)  # Total users: 101 (100 for Request1User, 1 for Request2User)

#         return None
 
# class UserDistribution:

#     """

#     Custom user distribution to assign 100 users to Request1User and 1 user to Request2User.

#     """

#     weight = {

#         Request1User: 1,

#         Request2User: 1

#     }
 
# # Specifica la classe CustomLoadTestShape come forma di test personalizzata
# #shape = CustomLoadTestShape()

 