from pywinauto import Application
 
def interact_with_print_dialog():


    try:

        # Connetti alla finestra di dialogo di stampa

        app = Application(backend="win32").connect(title="Stampa") #class_name="#32770", 

        print_dialog = app.window(title="Stampa") #class_name="#32770", 
 
        # Stampa i controlli disponibili nella finestra
        print_dialog.wait("visible",timeout=10)
 
        # Esempio: Fai clic sul pulsante "OK"
        print_dialog.child_window(title="Annulla",class_name="Button").click()


    except Exception as e:

        print(f"Errore durante l'interazione con la finestra di stampa: {e}")
 
# Esegui l'interazione

if __name__ == "__main__":
    interact_with_print_dialog()
 