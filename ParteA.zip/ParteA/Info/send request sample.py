## A) Invocare una Request con Python			

import requests

# URL del servizio SOAP del gestionale (esempio)
url = "https://tuo-endpoint-erp.it/soap/OrderSimulationService"

# XML della tua richiesta SOAP
xml_data = """<?xml version="1.0" encoding="UTF-8"?>
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                   xmlns:ns1="http://www.ipzs.it/ecommerce/b2b/types/1.0">
  <SOAP-ENV:Body>
    <ns1:OrderSimulationRequest>
      <ns1:Application>MAGENTO</ns1:Application>
      <ns1:CustomerType>2</ns1:CustomerType>
      <ns1:CustomerCodeEx>90013</ns1:CustomerCodeEx>
      <ns1:FiscalCode>03002470544</ns1:FiscalCode>
      <ns1:VATNumber>03002470544</ns1:VATNumber>
      <ns1:CountryISO>IT</ns1:CountryISO>
      <ns1:Region>TO</ns1:Region>
      <ns1:City>ANGROGNA</ns1:City>
      <ns1:ProductList>
        <ns1:Product>
          <ns1:ItemCode>10</ns1:ItemCode>
          <ns1:ProductCode>48-2MS10-25F0200</ns1:ProductCode>
          <ns1:Quantity>1</ns1:Quantity>
          <ns1:ProductType>1</ns1:ProductType>
          <ns1:PriceEx>98.00</ns1:PriceEx>
        </ns1:Product>
      </ns1:ProductList>
    </ns1:OrderSimulationRequest>
  </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
"""

# Headers SOAP standard
headers = {
    "Content-Type": "text/xml; charset=utf-8",
    "SOAPAction": ""  # spesso vuoto, o un URI se richiesto dal servizio
}

# Esegui la richiesta POST
response = requests.post(url, data=xml_data, headers=headers)

# Mostra il risultato
print("Status:", response.status_code)
print("Risposta SOAP:")
print(response.text)



## B) Invocare due Request contomparaneamente con Python

import asyncio
import aiohttp

# URL dell'endpoint SOAP
URL = "https://tuo-endpoint-erp.it/soap"

# XML delle due request
xml_simulation = """<?xml version="1.0" encoding="UTF-8"?>
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                   xmlns:ns1="http://www.ipzs.it/ecommerce/b2b/types/1.0">
  <SOAP-ENV:Body>
    <ns1:OrderSimulationRequest>
      <ns1:Application>MAGENTO</ns1:Application>
      <ns1:CustomerType>2</ns1:CustomerType>
      <ns1:CustomerCodeEx>90013</ns1:CustomerCodeEx>
      <ns1:ProductList>
        <ns1:Product>
          <ns1:ItemCode>10</ns1:ItemCode>
          <ns1:ProductCode>48-2MS10-25F0200</ns1:ProductCode>
          <ns1:Quantity>1</ns1:Quantity>
          <ns1:ProductType>1</ns1:ProductType>
          <ns1:PriceEx>98.00</ns1:PriceEx>
        </ns1:Product>
      </ns1:ProductList>
    </ns1:OrderSimulationRequest>
  </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
"""

xml_order = """<?xml version="1.0" encoding="UTF-8"?>
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
                   xmlns:ns1="http://www.ipzs.it/ecommerce/b2b/types/1.0">
  <SOAP-ENV:Body>
    <ns1:OrderRequest>
      <ns1:Application>MAGENTO</ns1:Application>
      <ns1:CustomerType>2</ns1:CustomerType>
      <ns1:CustomerCodeEx>90013</ns1:CustomerCodeEx>
      <ns1:Order>
        <ns1:OrderCodeEx>000253203</ns1:OrderCodeEx>
        <ns1:Total>131.0000</ns1:Total>
      </ns1:Order>
    </ns1:OrderRequest>
  </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
"""

headers = {"Content-Type": "text/xml; charset=utf-8"}

async def send_request(xml_data):
    async with aiohttp.ClientSession() as session:
        async with session.post(URL, data=xml_data, headers=headers) as resp:
            text = await resp.text()
            print(f"Risposta [{resp.status}]:\n{text}\n")

async def main():
    # Invia entrambe le richieste contemporaneamente
    await asyncio.gather(
        send_request(xml_simulation),
        send_request(xml_order)
    )

# Avvia le richieste in parallelo
asyncio.run(main())
